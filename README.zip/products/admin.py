from django.contrib import admin

from products.models import Products

admin.site.register(Products)
# Register your models here.
